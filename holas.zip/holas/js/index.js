(function (window, angular) {
  
'user strict';
  
angular.module('app', [])
.directive('bgImg', [function () {
  return {
    'restrict': 'A',
    'scope': true,
    'link': function ($scope, element, attrs) {
      
      $scope.setBg = function (srcImg) {
        
        if (!!!srcImg) {
          
         element[0].style.backgroundImage =  'url(' + attrs.bgSrc + ') ';

       } else {
         
         element[0].style.backgroundImage =  'url(' + srcImg + ') ';
       }
        
       element[0].style.backgroundRepeat = attrs.bgRepeat;
       element[0].style.backgroundSize = attrs.bgSize;
       element[0].style.backgroundAttachment = attrs.bgAttachment;
      };
      
      $scope.setBg();
    }
  };
  
}]);
  
}(window, angular));